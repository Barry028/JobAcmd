2022/01/21 更新

// 障別表單
apply_member.html

549 - 574 行 Js
422 - 482 行 html

1. 舊制 樣式修改 加上 下面 .sub-form-group 那一段
2. 所有 checkBox & radio 的 加上 label tabindex="0"
3. main.js 加上 check_wrap-label 的 keydown 事件

<input type="radio" id="oClassification3" name="oDisabled" value="4" class="check_input">
<label for="oClassification3" class="check_wrap-label width-auto" tabindex="0">
	<i class="check_mark"></i>
	<font class="txt">平衡機能障礙</font>
	<div id="oClassification3" class="sub-form-group">
	  <select name="disabled.type" id="oClassification3_sel" class="">
	    <option value="" disabled="" selected="">請選擇</option>
	    <option value="1">智能障礙者</option>
	    <option value="2">植物人</option>
	    <option value="2">失智症者</option>
	    <option value="2">自閉症者</option>
	  </select>
	  <input autocomplete="off" id="oClassification1_val3" class="" placeholder="請輸入說明" title="請輸入說明" type="text" value="">
	</div>
</label>


// Css
main.css
main.css.map